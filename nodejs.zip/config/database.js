module.exports={
    database:'mongodb://localhost/test'
}